<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'lapizzeria_wp' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '<FZhvC1)+:~xh<5VyK{sG1GY72gZ^Z&$b~?8u]6C8NCnk?E9W.hJ0-#G+dy1}4k.' );
define( 'SECURE_AUTH_KEY',  ':k^BRWt-dzs[`V@u!X]%C1.(&H0=V}NP_-Dr~$$aK:b Oh,+heTYu}^<0olA{l:T' );
define( 'LOGGED_IN_KEY',    'dn72^GsHL^e+Htc]WIirV)e+Gd#5gRPivO9qi:9/rIK).3t,w>X7lLKnx!d:=B=j' );
define( 'NONCE_KEY',        'uHq5L7xAVCtGF!nSLU&j-^At;s.|VW|7cFgecI5KRY$Lr]sigQXu`LKr?Fb(`,{3' );
define( 'AUTH_SALT',        'r>^k}U_)r{,7Q&zi2*<zZl^BjnySo.zl1:!ieBWh3aBNIRqor)dg~uC3OFqA16y`' );
define( 'SECURE_AUTH_SALT', 'j1$LT`y6s^6Yq9}>`#PY8d%=CyK-qAVI#)I#hdKZ*I[z5s+XNNB=t2FYND8+4u8L' );
define( 'LOGGED_IN_SALT',   '!zOMS_^r]N%)fti5o,R2/n:*@[i#!9.s,vhojJkX<URq2A1A]&~ut#n{ja9Kc9[6' );
define( 'NONCE_SALT',       'v/[iOuN1Z18PAm~h_^Q(N8@GHJUas!rY1YT~/sW%7He+|:V6Tzh}Q6L)&9 5R18H' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
